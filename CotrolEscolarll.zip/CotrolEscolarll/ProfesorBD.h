/*
 * ProfesorBD.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef PROFESORBD_H_
#define PROFESORBD_H_
#include "Profesor.h"
#include "ProfesorBD.h"
#include <string>
#include <pqxx/pqxx>
#include <iostream>

using namespace pqxx;
using namespace std;

class ProfesorBD {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
		string *sql;
	ProfesorBD();
	virtual ~ProfesorBD();
	/*string wGuardarAlumno(Alumno alumno);
	string wBuscarAlumno(Alumno curp);*/
		int wConsultarP();
		int wInsertarP();
		int wActualizarP();
		int wBorrarP();
		char* consultarP();
		char* insertarP(string matricula,string nombre, string primerapellido, string segundoapellido, string dia,string mes,string year);
		char* actualizarP(string matricula, string nombre, string primerApellido,string segundoApellido, string dia, string mes, string year);
		char* borrarP(string matricula, string nombre, string primerApellido, string segundoApellido, string dia, string mes, string year);
};

#endif /* PROFESORBD_H_ */
