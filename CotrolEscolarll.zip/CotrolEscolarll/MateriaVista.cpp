/*
 * MateriaVista.cpp
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#include "MateriaVista.h"
#include "Materia.h"
#include <string>
#include <iostream>
using namespace std;

MateriaVista::MateriaVista() {
	// TODO Auto-generated constructor stub

}

MateriaVista::~MateriaVista() {
	// TODO Auto-generated destructor stub
}

void MateriaVista::wRegistraMateria(){
	Materia* materia;
	materia = new Materia();
	string idMateria,nombre;

	cout<<"Ingrese el id de la materia: "<<endl;
	cin>>idMateria;
	materia->setIdMateria(idMateria);

	cout<<"Nombre(s):"<<endl;
	cin>>nombre;
	materia->setNombre(nombre);
}

