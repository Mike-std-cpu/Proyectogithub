/*
 * AlumnoBD.cpp
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#include "AlumnoBD.h"
#include "AlumnoVista.h"
#include <iostream>
#include <pqxx/pqxx>
#include <string.h>
using namespace std;
using namespace pqxx;

AlumnoBD::AlumnoBD() {
	// TODO Auto-generated constructor stub

}

AlumnoBD::~AlumnoBD() {
	// TODO Auto-generated destructor stub
}

int  AlumnoBD::wConsultarA(){

try{
connection c(cadenaConexion);
if(c.is_open()){
cout<<"Se conecto a la BD: "<<" "<<c.dbname();
//cout<<"\nSELECT a tabla alumno";
nontransaction N(c); // * Crear un objeto no transaccional. *
int size=sql->size();
result R(N.exec(this->consultarA())); // * Ejecutar consulta SQL *
cout<<"\n Matricula\tnombre\t\t Primer apellido\t Segundo apellido\t Dia\t Mes\t Año "<<endl;
cout<<"=================================================="<<endl;
for(result::const_iterator c=R.begin(); c!=R.end();++c){
cout<<" "<<c[0].as<string>()<<"\t\t";
cout<<" "<<c[1].as<string>()<<"\t\t";
cout<<" "<<c[2].as<string>()<<"\t\t";
cout<<" "<<c[3].as<string>()<<"\t\t";
cout<<" "<<c[4].as<string>()<<"\t\t";
cout<<" "<<c[5].as<string>()<<"\t\t";
cout<<" "<<c[6].as<string>()<<endl;
	}
}else {
cout<<"No se conecto a la Base de datos"<<endl;
return 1;
}
c.disconnect();
}catch (const std::exception &e) {
cerr<<e.what()<<std::endl;
return 1;
}
return 0;
}

char* AlumnoBD::consultarA(){
sql=new string("select * from Alumno");
int size;
size=sql->size()+1;
char *query=new char[size];
strcpy(query, sql->c_str());
return query;

}
// Insert
int  AlumnoBD::wInsertarA(/*string matricula, string nombre, string primerApellido, string segundoAPellido,int dia, int mes, int year*/){
try{
connection c(cadenaConexion);
if(c.is_open()){
work W(c); //AGREGADO *** / * Crear un objeto transaccional. * /
int size=sql->size();
string matricula,nombre,primerApellido,segundoApellido, dia, mes, year;

cout << "Matricula (8 digitos)\n";
cin >> matricula;
cout << "\nNombre\n";
cin >> nombre;
cout << "Primer apellido\n";
cin >> primerApellido;
cout << "Segundo apellido\n";
cin >> segundoApellido;
cout<<"Fecha de nacimiento dd mm aaaa:"<<endl;
cin>>dia>>mes>>year;
/*AlumnoVista alumnos();
alumnos.wRegistraAlumno();*/

W.exec(this->insertarA(matricula,nombre, primerApellido, segundoApellido,dia,mes,year)); //AGREGADO ***/ * Ejecutar consulta SQL * /
cout << "Valores insertados exitosamente" << endl;
W.commit(); //COMMIT es el comando SQL que se utiliza para almacenar los cambios realizados por una transacción.
cout<<"*****************"<<endl;
}else {
cout<<"No se conecto a la Base de datos"<<endl;
return 1;
}
c.disconnect();
}catch (const std::exception &e) {
cerr<<e.what()<<std::endl;
return 1;
}
return 0;
}

char* AlumnoBD::insertarA(string matricula,string nombre, string primerApellido, string segundoApellido,string dia,string mes,string year){
sql=new string( "INSERT INTO Alumno (matricula,nombre,primerApellido,segundoApellido,dia,mes,year)" \
		       "VALUES (\'" + matricula + "\', \'" + nombre + "\', \'" + primerApellido + "\', \'" + segundoApellido + "\', \'" + dia + "\', \'" + mes + "\', \'" + year + "\');");
int size;
size=sql->size()+1;
char *query=new char[size];
strcpy(query, sql->c_str());
return query;

}
