//Main Principal

#include "Alumno.h"
#include "Profesor.h"
#include "Materia.h"
#include "AlumnoVista.h"
#include "ProfesorVista.h"
#include "MateriaVista.h"
//#include "AlumnoBS.h"
//#include "ProfesorBS.h"
//#include "MateriaBS.h"
#include "AlumnoBD.h"
#include "ProfesorBD.h"
#include "MateriaBD.h"
#include <iostream>
using namespace std;

int main(int argc, char **argv) {
int opc;
//Alumno
	AlumnoBD *alumno;
	alumno=new AlumnoBD();
//profesor
	ProfesorBD *profe;
	profe=new ProfesorBD();
//Materia
	MateriaBD *materia;
	materia=new MateriaBD();


do{
	cout<<"         Menu      "<<endl;
	cout<<"1. Registrar alumno. "<<endl;
	cout<<"2. Registrar maestro. "<<endl;
	cout<<"3. Registrar materias. "<<endl;
	cout<<"4. Administrar grupos. "<<endl;
	cout<<"5. Asignar materias a profesor. "<<endl;
	cout<<"6. Inscribir alumno a un curso. "<<endl;
	cout<<"7. Salir."<<endl<<endl;

	cout<<"Ingrese un numero para acceder a una opcion del menu."<<endl;
cin>>opc;
switch(opc){

	case 1:
		alumno->wInsertarA();
		alumno->wConsultarA();
		break;

	case 2:
		//profe->wInsertarP();
		profe->wConsultarP();
		break;

	case 3:
		//materia->wInsertarM();
		materia->wConsultarM();
default:
	cout<<"salir ...";
	}
}while(opc != 5);
return 0;
}
