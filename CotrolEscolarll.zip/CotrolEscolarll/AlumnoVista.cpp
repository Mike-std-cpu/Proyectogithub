/*
 * AlumnoVista.cpp
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#include "AlumnoVista.h"
#include "Alumno.h"
#include <string>
#include <iostream>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

AlumnoVista::AlumnoVista() {
	// TODO Auto-generated constructor stub

}

AlumnoVista::~AlumnoVista() {
	// TODO Auto-generated destructor stub
}

void AlumnoVista::wRegistraAlumno(){
	Alumno* alumno;
	alumno = new Alumno();
	string matricula,nombre,primerApellido,segundoApellido,curp;
	int dia,mes,year;

	cout<<"Matriucla: "<<endl;
	cin>>matricula;
	alumno->setMatricula(matricula);

	cout<<"Nombre(s):"<<endl;
	cin>>nombre;
	alumno->setNombre(nombre);

	cout<<"Ingrese Primer Apellido:"<<endl;
	cin>>primerApellido;
	alumno->setPrimerApellido(primerApellido);

	cout<<"Ingrese segundo Apellido:"<<endl;
	cin>>segundoApellido;
	alumno->setSegundoApellido(segundoApellido);

	cout<<"Fecha de nacimiento dd mm aaaa:"<<endl;
	cin>>dia>>mes>>year;
	alumno->setDia(dia);
	alumno->setMes(mes);
	alumno->setYear(year);

	cout<<"Ingrese CURP:"<<endl;
	cin>>curp;
	alumno->setCurp(curp);
}
