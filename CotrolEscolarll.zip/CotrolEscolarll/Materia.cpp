/*
 * Materia.cpp
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#include "Materia.h"
#include<iostream>
#include<string.h>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

Materia::Materia() {
	// TODO Auto-generated constructor stub

}

Materia::~Materia() {
	// TODO Auto-generated destructor stub
}

	void Materia::setIdMateria(string idmateria){
		this-> idMateria=idmateria;
	}
	string Materia::getIdMateria(){
		return idMateria;
	}

	void Materia::setNombre(string nombre){
		this->nombre=nombre;
	}

	string Materia::getNombre(){
		return nombre;
	}
