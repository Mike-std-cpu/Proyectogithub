/*
 *
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */
#ifndef ALUMNOBD_H_
#define ALUMNOBD_H_
#include "Alumno.h"
#include "AlumnoBD.h"
#include <string>
#include <pqxx/pqxx>
#include <iostream>

using namespace pqxx;
using namespace std;

class AlumnoBD {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
			string *sql;
	AlumnoBD();
	virtual ~AlumnoBD();
	/*string wGuardarAlumno(Alumno alumno);
	string wBuscarAlumno(Alumno curp);*/
			int wConsultarA();
			int wInsertarA();
			int wActualizarA();
			int wBorrarA();
			char* consultarA();
			char* insertarA(string matricula,string nombre, string primerapellido, string segundoapellido, string dia,string mes,string year);
			char* actualizarA(string matricula, string nombre, string primerApellido,string segundoApellido, string dia, string mes, string year);
			char* borrarA(string matricula, string nombre, string primerApellido, string segundoApellido, string dia, string mes, string year);
};

#endif /* ALUMNOBD_H_ */
