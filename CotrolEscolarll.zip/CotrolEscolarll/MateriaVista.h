/*
 * MateriaVista.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef MATERIAVISTA_H_
#define MATERIAVISTA_H_

class MateriaVista {
public:
	MateriaVista();
	virtual ~MateriaVista();
	void wRegistraMateria();
};

#endif /* MATERIAVISTA_H_ */
