/*
 * ProfesorVista.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef PROFESORVISTA_H_
#define PROFESORVISTA_H_

class ProfesorVista {
public:
	ProfesorVista();
	virtual ~ProfesorVista();
	void wRegistraProfesor();
};

#endif /* PROFESORVISTA_H_ */
