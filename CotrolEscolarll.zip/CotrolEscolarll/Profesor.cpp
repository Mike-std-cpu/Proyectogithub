/*
 * Profesor.cpp
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#include "Profesor.h"
#include<iostream>
#include<string>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

Profesor::Profesor() {
	// TODO Auto-generated constructor stub

}

Profesor::~Profesor() {
	// TODO Auto-generated destructor stub
}

void Profesor::setMatriculaprofesor(string matriculaprofesor){
		this-> matriculaprofesor = matriculaprofesor;
	}
string Profesor::getMatriculaprofesor(){
		return matriculaprofesor;
	}

void Profesor::setNombre(string nombre){
	this->nombre=nombre;
	}

	string Profesor::getNombre(){
		return nombre;
	}

	void Profesor::setPrimerApellido(string primerApellido){
		this->primerApellido = primerApellido;
	}

	string Profesor::getPrimerApellido(){
		return primerApellido;
	}

	void Profesor::setSegundoApellido(string segundoApellido){
		this->segundoApellido = segundoApellido;
	}
	string Profesor::getSegundoApellido(){
		return segundoApellido;
	}

	void Profesor::setDia(int dia){
		this->dia = dia;
	}

	int Profesor::getDia(){
	return dia;
	}
	void Profesor::setMes(int mes){
		this->mes = mes;
	}
	int Profesor::getMes(){
		return mes;
	}
	void Profesor::setYear(int year){
		this-> year = year;
	}
	int Profesor::getYear(){
		return year;
	}

