/*
 * Materia.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef MATERIA_H_
#define MATERIA_H_
#include<iostream>
#include<string>

using namespace std;

class Materia {
private:
		string idMateria;
		string nombre;
public:
	Materia();
	virtual ~Materia();
	void setIdMateria(string idmateria);
		string getIdMateria();

		void setNombre(string nombre);
		string getNombre();
};

#endif /* MATERIA_H_ */
