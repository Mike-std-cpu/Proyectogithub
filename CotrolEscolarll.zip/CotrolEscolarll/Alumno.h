/*
 * Alumno.h
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#ifndef ALUMNO_H_
#define ALUMNO_H_
#include<iostream>
#include<string>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

class Alumno {
private:
	string matricula;
	string nombre;
	string primerApellido;
	string segundoApellido;
	int dia;
	int mes;
	int year;
	string curp;
public:
	Alumno();
		virtual ~Alumno();
		void setMatricula(string matricula);
		string getMatricula();

		void setNombre(string nombre);
		string getNombre();

		void setPrimerApellido(string primerApellido);
		string getPrimerApellido();

		void setSegundoApellido(string segundoApellido);
		string getSegundoApellido();

		void setDia(int dia);
		int getDia();

		void setMes(int mes);
		int getMes();

		void setYear(int year);
		int getYear();

		void setCurp(string curp);
		string getCurp();
};

#endif /* ALUMNO_H_ */
