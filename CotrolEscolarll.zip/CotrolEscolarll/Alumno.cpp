/*
 * Alumno.cpp
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#include "Alumno.h"
#include<iostream>
#include<string>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

Alumno::Alumno() {
	// TODO Auto-generated constructor stub

}

Alumno::~Alumno() {
	// TODO Auto-generated destructor stub
}

void Alumno::setMatricula(string matricula){
		this-> matricula = matricula;
	}
string Alumno::getMatricula(){
		return matricula;
	}

void Alumno::setNombre(string nombre){
	this->nombre=nombre;
	}

	string Alumno::getNombre(){
		return nombre;
	}

	void Alumno::setPrimerApellido(string primerApellido){
		this->primerApellido = primerApellido;
	}

	string Alumno::getPrimerApellido(){
		return primerApellido;
	}

	void Alumno::setSegundoApellido(string segundoApellido){
		this->segundoApellido = segundoApellido;
	}
	string Alumno::getSegundoApellido(){
		return segundoApellido;
	}

	void Alumno::setDia(int dia){
		this->dia = dia;
	}

	int Alumno::getDia(){
	return dia;
	}
	void Alumno::setMes(int mes){
		this->mes = mes;
	}
	int Alumno::getMes(){
		return mes;
	}
	void Alumno::setYear(int year){
		this-> year = year;
	}
	int Alumno::getYear(){
		return year;
	}
	string Alumno::getCurp(){
		return curp;
	}
	void Alumno::setCurp(string curp){
		this->curp=curp;
	}
