/*
 * MateriaBD.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef MATERIABD_H_
#define MATERIABD_H_
#include "Materia.h"
#include "MateriaBD.h"
#include <string>
#include <pqxx/pqxx>
#include <iostream>

using namespace pqxx;
using namespace std;

class MateriaBD {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
		  string *sql;
	MateriaBD();
	virtual ~MateriaBD();
	/*string wGuardarAlumno(Alumno alumno);
	string wBuscarAlumno(Alumno curp);*/
		int wConsultarM();
		int wInsertarM();
		int wActualizarM();
		int wBorrarM();
		char* consultarM();
		char* insertarM(string idmateria,string nombre);
		char* actualizarM(string idmateria, string nombre);
		char* borrarM(string idmateria, string nombre);
};

#endif /* MATERIABD_H_ */
