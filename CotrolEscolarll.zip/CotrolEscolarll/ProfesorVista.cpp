/*
 * ProfesorVista.cpp
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#include "ProfesorVista.h"
#include "Profesor.h"
#include <string>
#include <iostream>
using namespace std;

ProfesorVista::ProfesorVista() {
	// TODO Auto-generated constructor stub

}

ProfesorVista::~ProfesorVista() {
	// TODO Auto-generated destructor stub
}

void ProfesorVista::wRegistraProfesor(){
	Profesor* profesor;
	profesor = new Profesor();
	string matriculaprofesor,nombre,primerApellido,segundoApellido,curp;
	int dia,mes,year;

	cout<<"Matriucla de Profesor: "<<endl;
	cin>>matriculaprofesor;
	profesor->setMatriculaprofesor(matriculaprofesor);

	cout<<"Nombre(s):"<<endl;
	cin>>nombre;
	profesor->setNombre(nombre);

	cout<<"Ingrese Primer Apellido:"<<endl;
	cin>>primerApellido;
	profesor->setPrimerApellido(primerApellido);

	cout<<"Ingrese segundo Apellido:"<<endl;
	cin>>segundoApellido;
	profesor->setSegundoApellido(segundoApellido);

	cout<<"Fecha de nacimiento dd mm aaaa:"<<endl;
	cin>>dia>>mes>>year;
	profesor->setDia(dia);
	profesor->setMes(mes);
	profesor->setYear(year);
}

