/*
 * Profesor.h
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#ifndef PROFESOR_H_
#define PROFESOR_H_
#include<iostream>
#include<string>
#include <pqxx/pqxx>

using namespace pqxx;
using namespace std;

class Profesor {
private:
		string matriculaprofesor;
		string nombre;
		string primerApellido;
		string segundoApellido;
		int dia;
		int mes;
		int year;
public:
	Profesor();
	virtual ~Profesor();
	void setMatriculaprofesor(string matriculaprofesor);
			string getMatriculaprofesor();

	void setNombre(string nombre);
			string getNombre();

	void setPrimerApellido(string primerApellido);
			string getPrimerApellido();

	void setSegundoApellido(string segundoApellido);
			string getSegundoApellido();

	void setDia(int dia);
			int getDia();

	void setMes(int mes);
			int getMes();

	void setYear(int year);
			int getYear();

};

#endif /* PROFESOR_H_ */
