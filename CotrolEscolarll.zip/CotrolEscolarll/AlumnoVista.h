/*
 * AlumnoVista.h
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#ifndef ALUMNOVISTA_H_
#define ALUMNOVISTA_H_
#include "Alumno.h"

class AlumnoVista {
public:
	AlumnoVista();
	virtual ~AlumnoVista();
	void wRegistraAlumno();
};

#endif /* ALUMNOVISTA_H_ */
