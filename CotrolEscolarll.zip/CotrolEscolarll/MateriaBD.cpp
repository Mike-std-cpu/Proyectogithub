/*
 * MateriaBD.cpp
 *
 *  Created on: Jul 8, 2020
 *      Author: curso
 */

#include "MateriaBD.h"
#include "MateriaVista.h"
#include <iostream>
#include <pqxx/pqxx>
#include <string.h>

using namespace std;
using namespace pqxx;

MateriaBD::MateriaBD() {
	// TODO Auto-generated constructor stub

}

MateriaBD::~MateriaBD() {
	// TODO Auto-generated destructor stub
}

int  MateriaBD::wConsultarM(){

try{
connection c(cadenaConexion);
if(c.is_open()){
cout<<"Se conecto a la BD: "<<" "<<c.dbname();
//cout<<"\nSELECT a tabla alumno";
nontransaction N(c); // * Crear un objeto no transaccional. *
int size=sql->size();
result R(N.exec(this->consultarM())); // * Ejecutar consulta SQL *
cout<<"\n Matricula\tnombre\t"<<endl;
cout<<"=================================================="<<endl;
for(result::const_iterator c=R.begin(); c!=R.end();++c){
cout<<" "<<c[0].as<string>()<<"\t\t";
cout<<" "<<c[1].as<string>()<<"\t\t";
cout<<" "<<c[2].as<string>()<<"\t\t";
/*cout<<" "<<c[3].as<string>()<<"\t\t";
cout<<" "<<c[4].as<string>()<<"\t\t";
cout<<" "<<c[5].as<string>()<<"\t\t";
cout<<" "<<c[6].as<string>()<<endl;*/
	}
}else {
cout<<"No se conecto a la Base de datos"<<endl;
return 1;
}
c.disconnect();
}catch (const std::exception &e) {
cerr<<e.what()<<std::endl;
return 1;
}
return 0;
}

char* MateriaBD::consultarM(){
sql=new string("select * from materia");
int size;
size=sql->size()+1;
char *query=new char[size];
strcpy(query, sql->c_str());
return query;

}
// Insert
int  MateriaBD::wInsertarM(/*string matricula, string nombre, string primerApellido, string segundoAPellido,int dia, int mes, int year*/){
try{
connection c(cadenaConexion);
if(c.is_open()){
work W(c); //AGREGADO *** / * Crear un objeto transaccional. * /
int size=sql->size();
string idmateria,nombre;

cout << "ID de la materia: (8 digitos)\n";
cin >> idmateria;
cout << "\nNombre\n";
cin >> nombre;
cout<<endl;
/*AlumnoVista alumnos();
alumnos.wRegistraAlumno();*/

W.exec(this->insertarM(idmateria,nombre)); //AGREGADO ***/ * Ejecutar consulta SQL * /
cout << "Valores insertados exitosamente" << endl;
W.commit(); //COMMIT es el comando SQL que se utiliza para almacenar los cambios realizados por una transacción.
cout<<"*****************"<<endl;
}else {
cout<<"No se conecto a la Base de datos"<<endl;
return 1;
}
c.disconnect();
}catch (const std::exception &e) {
cerr<<e.what()<<std::endl;
return 1;
}
return 0;
}

char* MateriaBD::insertarM(string idmateria,string nombre){
sql=new string( "INSERT INTO materia (idmateria,nombre)" \
		       "VALUES (\'" + idmateria + "\', \'" + nombre + "\');");
int size;
size=sql->size()+1;
char *query=new char[size];
strcpy(query, sql->c_str());
return query;

}

