/*
 * Conexion.h
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#ifndef CONEXION_H_
#define CONEXION_H_
#include <string>
#include <pqxx/pqxx>
using namespace pqxx;
#include <iostream>
using namespace std;

class Conexion {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
		string *sql;
		Conexion();
		virtual ~Conexion();
		int wConsultar();
		int wInsertar();
		int wActualizar();
		int wBorrar();
		char* consultar();
		char* insertar(string matricula,string nombre, string primerapellido, string segundoapellido,string dia,string mes,string year);
		char* actualizar();
		char* borrar();
};

#endif /* CONEXION_H_ */
