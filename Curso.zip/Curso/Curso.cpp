//Main Principal
#include "Conexion.h"
#include "ConexionP.h"
#include "ConexionM.h"
#include <iostream>
using namespace std;
int main(int argc, char **argv) {
int opc;

Conexion *prueba;
prueba=new Conexion();

ConexionP *pruebap;
pruebap=new ConexionP();

ConexionM *pruebam;
pruebam=new ConexionM();


do{
	cout<<"C O N T R O L   E S C O L A R \n"<<endl;
	cout<<" Seleccione una opcion: "<<endl;
	cout<<"\n1- SELECT * FROM alumno \n";
	cout<<"2.- Ingresar Alumno \n";
	cout<<"3.- Registrar Profesor \n";
	cout<<"4.- Registrar Materia \n";
	cout<<"5.- Asignar Materia a profesor \n";
	cout<<"6.- Asignar curso a Alumno \n";
	cout<<"7.- Asignar materia a profesor \n";/*
	cout<<"3- UPDATE alumno set nombre \n";
	cout<<"4- DELETE alumno set nombre \n";*/
	cout<<"5- Salir \n";
cin>>opc;
switch(opc){
case 1:
cout<<"\nSELECT a tabla alumno\n";
prueba->wConsultar();
break;

//Insert INTO alumno
case 2:
//prueba->insertar(nombre,primerapellido,segundoapellido);
prueba->wInsertar();
cout<<"¿Desea Modificar un dato?"<<endl;
int r;
cin>>r;
if(r==1){
	cout<<"Si";
}else{
	cout<<"No";
}
prueba->wConsultar();
break;

case 3:
	//pruebap->wInsertarp();
	pruebap->wConsultarp();
break;
case 4:
	pruebam->wInsertarm();
	pruebam->wConsultarm();
break;
//case 3://
/*cout << "\n-Tabla actual- " << endl;
prueba->wConsultar();
prueba->wActualizar();
cout << "\n-Tabla actualizada- " << endl;
prueba->wConsultar();*/
//break;
//case 4://
/*cout << "\n-Tabla actual- " << endl;
prueba->wConsultar();
prueba->wBorrar();
cout << "\n-Tabla actualizada- " << endl;
prueba->wConsultar();*/
//break;
default:
	cout<<"salir ...";
	}
}while(opc != 5);
return 0;
}
