/*
 * ConexionP.h
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#ifndef CONEXIONP_H_
#define CONEXIONP_H_
#include <string>
#include <pqxx/pqxx>
using namespace pqxx;
#include <iostream>
using namespace std;

class ConexionP {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
		string *sql;
	ConexionP();
	virtual ~ConexionP();
	int wConsultarp();
	int wInsertarp();
	int wActualizarp();
	int wBorrap();
	char* consultarp();
	char* insertarp(string matriculaprofesor,string nombre, string primerapellido, string segundoapellido);
	char* actualizarp();
	char* borrarp();

};

#endif /* CONEXIONP_H_ */
