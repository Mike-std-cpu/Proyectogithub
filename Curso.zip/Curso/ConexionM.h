/*
 * ConexionM.h
 *
 *  Created on: Jul 7, 2020
 *      Author: curso
 */

#ifndef CONEXIONM_H_
#define CONEXIONM_H_
#include <string>
#include <pqxx/pqxx>
using namespace pqxx;
#include <iostream>
using namespace std;

class ConexionM {
public:
	const string cadenaConexion= "dbname=proyecto user=fpoo password=fpoo hostaddr = 127.0.0.1 port=5432";
		string *sql;
	ConexionM();
	virtual ~ConexionM();
	int wConsultarm();
	int wInsertarm();
	int wActualizarm();
	int wBorram();
	char* consultarm();
	char* insertarm(string idmateria,string nombre);
	char* actualizarm();
	char* borrarm();
};

#endif /* CONEXIONM_H_ */
